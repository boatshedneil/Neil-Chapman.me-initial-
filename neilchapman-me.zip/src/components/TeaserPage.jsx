import React from "react";

export default function TeaserPage() {
  return (
    <section className="border-t pt-8 mt-8 border-gray-700">
      <h2 className="text-2xl font-semibold">Experiments in Digital Selfhood</h2>
      <p className="mt-4 max-w-xl">
        This site isn’t about who I am. It’s about what happens when a founder decides
        to build a digital version of himself—just to see what breaks.
      </p>
      <p className="mt-2 italic text-gray-400">It might be useful. It might be uncomfortable. It might get weird. That’s the point.</p>
    </section>
  );
}