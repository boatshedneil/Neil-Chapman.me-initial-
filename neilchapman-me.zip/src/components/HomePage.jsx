import React from "react";

export default function HomePage() {
  return (
    <div className="mb-12">
      <h1 className="text-4xl font-bold">Neil Chapman</h1>
      <p className="mt-4 text-lg italic text-gray-400">
        Building better founders by open-sourcing myself.
      </p>
      <p className="mt-6 max-w-xl">
        Founder. Systems obsessive. Bit obsessed with boats. Also: death,
        decentralisation, and what comes after “personal brand.”
      </p>
    </div>
  );
}