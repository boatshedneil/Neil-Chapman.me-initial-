import React from "react";
import HomePage from "./components/HomePage";
import TeaserPage from "./components/TeaserPage";

export default function App() {
  return (
    <main className="p-10">
      <HomePage />
      <TeaserPage />
    </main>
  );
}